import { createClient } from "@supabase/supabase-js";
import { Customer, Product, Batch, Order } from "../type/schema";

// Inisialisasi Supabase client
const supabaseUrl = 'https://yonkghtpwajrnevhbsqp.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlvbmtnaHRwd2Fqcm5ldmhic3FwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDEzNDYxMzMsImV4cCI6MjA1NjkyMjEzM30.EhS8XiErvaXf7kyf-SULEhpyRMf070JkgzItggfkr4w';
const supabase = createClient(supabaseUrl, supabaseKey);

// Helper function to handle Supabase errors
const handleSupabaseError = (error: any) => {
  if (error.message?.includes('fetch') || error.message?.includes('network') || error.code === 'ERR_NETWORK') {
    console.error('Supabase connection error:', error);
    return null;
  }
  throw error;
};

// Customer functions
export const getCustomers = async (): Promise<Customer[]> => {
  try {
    const { data, error } = await supabase
      .from('customers')
      .select('*, brand')
      .order('name');
      
    if (error) throw error;
    return data || [];
  } catch (error) {
    if (handleSupabaseError(error) === null) {
      return [];
    }
    throw error;
  }
};

export const getCustomerById = async (id: string): Promise<Customer | null> => {
  try {
    const { data, error } = await supabase
      .from('customers')
      .select('*, brand')
      .eq('id', id)
      .single();
      
    if (error) throw error;
    return data;
  } catch (error) {
    if (handleSupabaseError(error) === null) {
      return null;
    }
    throw error;
  }
};

export const createCustomer = async (customer: Omit<Customer, 'id'>): Promise<Customer> => {
  try {
    const { data, error } = await supabase
      .from('customers')
      .insert([{ 
        ...customer,
        brand: customer.brand,
        city: customer.city // Tambahkan ini
      }])
      .select()
      .single();
      
    if (error) throw error;
    return data;
  } catch (error) {
    handleSupabaseError(error);
    throw error;
  }
};

export const updateCustomer = async (id: string, customer: Partial<Customer>): Promise<Customer> => {
  try {
    const { data, error } = await supabase
      .from('customers')
      .update({
        ...customer,
        brand: customer.brand,
        city: customer.city // Tambahkan ini
      })
      .eq('id', id)
      .select()
      .single();
      
    if (error) throw error;
    return data;
  } catch (error) {
    handleSupabaseError(error);
    throw error;
  }
};

export const deleteCustomer = async (id: string): Promise<void> => {
  try {
    const { error } = await supabase
      .from('customers')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  } catch (error) {
    handleSupabaseError(error);
    throw error;
  }
};

// Product functions
export const getProducts = async (): Promise<Product[]> => {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('name');
      
    if (error) throw error;
    return data || [];
  } catch (error) {
    if (handleSupabaseError(error) === null) {
      return [];
    }
    throw error;
  }
};

export const getProductById = async (id: string): Promise<Product | null> => {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', id)
      .single();
      
    if (error) throw error;
    return data;
  } catch (error) {
    if (handleSupabaseError(error) === null) {
      return null;
    }
    throw error;
  }
};

export const createProduct = async (product: Omit<Product, 'id'>): Promise<Product> => {
  try {
    const { data, error } = await supabase
      .from('products')
      .insert([product])
      .select()
      .single();
      
    if (error) throw error;
    return data;
  } catch (error) {
    handleSupabaseError(error);
    throw error;
  }
};

export const updateProduct = async (id: string, product: Partial<Product>): Promise<Product> => {
  try {
    const { data, error } = await supabase
      .from('products')
      .update(product)
      .eq('id', id)
      .select()
      .single();
      
    if (error) throw error;
    return data;
  } catch (error) {
    handleSupabaseError(error);
    throw error;
  }
};

export const deleteProduct = async (id: string): Promise<void> => {
  try {
    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  } catch (error) {
    handleSupabaseError(error);
    throw error;
  }
};

// Batch functions
export const getBatches = async (): Promise<Batch[]> => {
  try {
    const { data, error } = await supabase
      .from('batches')
      .select('*, batch_products(*, product:products(*))');
      
    if (error) throw error;
    return data || [];
  } catch (error) {
    if (handleSupabaseError(error) === null) {
      return [];
    }
    throw error;
  }
};

export const getBatchById = async (id: string): Promise<Batch | null> => {
  try {
    const { data, error } = await supabase
      .from('batches')
      .select('*, batch_products(*, product:products(*))')
      .eq('id', id)
      .single();
      
    if (error) throw error;
    return data;
  } catch (error) {
    if (handleSupabaseError(error) === null) {
      return null;
    }
    throw error;
  }
};

export const createBatch = async (
  batch: Omit<Batch, 'id' | 'products'>,
  batchProducts: { product_id: string; initial_qty: number; remaining_qty: number }[]
): Promise<Batch> => {
  const { data: batchData, error: batchError } = await supabase
    .from('batches')
    .insert([{ 
      batch_id: batch.batch_id,
      created_at: new Date().toISOString(),
      status: batch.status,
    }])
    .select()
    .single();
    
  if (batchError) throw batchError;
  
  const batchProductsWithBatchId = batchProducts.map(bp => ({
    ...bp,
    batch_id: batchData.id
  }));
  
  const { error: productsError } = await supabase
    .from('batch_products')
    .insert(batchProductsWithBatchId);
    
  if (productsError) throw productsError;
  
  return getBatchById(batchData.id) as Promise<Batch>;
};

export const updateBatch = async (
  id: string,
  batch: Partial<Omit<Batch, 'id' | 'products'>>,
  batchProducts?: { id?: string; product_id: string; initial_qty: number; remaining_qty: number }[]
): Promise<Batch> => {
  const { error: batchError } = await supabase
    .from('batches')
    .update({
      batch_id: batch.batch_id,
      status: batch.status,
    })
    .eq('id', id);
    
  if (batchError) throw batchError;

  if (batchProducts && batchProducts.length > 0) {
    for (const product of batchProducts) {
      if (product.id) {
        const { error } = await supabase
          .from('batch_products')
          .update({
            initial_qty: product.initial_qty,
            remaining_qty: product.remaining_qty
          })
          .eq('id', product.id);
          
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('batch_products')
          .insert([{
            batch_id: id,
            product_id: product.product_id,
            initial_qty: product.initial_qty,
            remaining_qty: product.remaining_qty
          }]);
          
        if (error) throw error;
      }
    }
  }
  
  return getBatchById(id) as Promise<Batch>;
};

export const updateBatchStatus = async (id: string, status: string): Promise<void> => {
  const { error } = await supabase
    .from('batches')
    .update({ status })
    .eq('id', id)
    .select();
    
  if (error) {
    console.error('Supabase error in updateBatchStatus:', error);
    throw error;
  }
};

export const deleteBatch = async (id: string): Promise<void> => {
  try {
    const { error } = await supabase
      .from('batches')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  } catch (error) {
    handleSupabaseError(error);
    throw error;
  }
};

// Order functions
export const getOrders = async (): Promise<Order[]> => {
  const { data, error } = await supabase
    .from('orders')
    .select('*, customers(*), order_items(*, product:products(*))')
    .order('created_at', { ascending: false });
    
  if (error) {
    console.error('Supabase error in getOrders:', error);
    throw error;
  }
  return data || [];
};

export const getOrderById = async (id: string): Promise<Order | null> => {
  const { data, error } = await supabase
    .from('orders')
    .select('*, customers(*), order_items(*, product:products(*))')
    .eq('id', id)
    .single();
    
  if (error) {
    console.error('Supabase error in getOrderById:', error);
    throw error;
  }
  return data;
};

export const createOrder = async (
  order: { customer_id: string; batch_id: string; status: string; },
  orderItems: { product_id: string; qty: number; price: number; }[]
): Promise<Order> => {
  const { data: orderData, error: orderError } = await supabase
    .from('orders')
    .insert([{ 
      customer_id: order.customer_id,
      batch_id: order.batch_id,
      status: order.status,
      created_at: new Date().toISOString() 
    }])
    .select()
    .single();
    
  if (orderError) {
    console.error('Supabase error in createOrder (order insert):', orderError);
    throw orderError;
  }
  
  const orderItemsWithOrderId = orderItems.map(item => ({
    ...item,
    order_id: orderData.id
  }));
  
  const { error: itemsError } = await supabase
    .from('order_items')
    .insert(orderItemsWithOrderId);
    
  if (itemsError) {
    console.error('Supabase error in createOrder (order items insert):', itemsError);
    throw itemsError;
  }
  
  for (const item of orderItems) {
    const { data: batchProduct, error: bpError } = await supabase
      .from('batch_products')
      .select('*')
      .eq('batch_id', order.batch_id)
      .eq('product_id', item.product_id)
      .single();
      
    if (bpError) {
      console.error('Supabase error in createOrder (batch product fetch):', bpError);
      throw bpError;
    }
    
    if (batchProduct) {
      const { error: updateError } = await supabase
        .from('batch_products')
        .update({ 
          remaining_qty: batchProduct.remaining_qty - item.qty 
        })
        .eq('id', batchProduct.id)
        .select();
        
      if (updateError) {
        console.error('Supabase error in createOrder (batch product update):', updateError);
        throw updateError;
      }
    }
  }
  
  return getOrderById(orderData.id) as Promise<Order>;
};

export const updateOrder = async (
  id: string, 
  order: { customer_id: string; batch_id: string; status: 'pending' | 'confirmed' | 'cancelled' },
  orderItems: { product_id: string; qty: number; price: number }[]
): Promise<Order> => {
  try {
    const { data: orderData, error: orderError } = await supabase
      .from('orders')
      .update({ 
        customer_id: order.customer_id,
        batch_id: order.batch_id,
        status: order.status
      })
      .eq('id', id)
      .select()
      .single();
      
    if (orderError) throw orderError;

    const { error: deleteError } = await supabase
      .from('order_items')
      .delete()
      .eq('order_id', id);
      
    if (deleteError) throw deleteError;

    const orderItemsWithOrderId = orderItems.map(item => ({
      ...item,
      order_id: id
    }));
    
    const { error: itemsError } = await supabase
      .from('order_items')
      .insert(orderItemsWithOrderId);
      
    if (itemsError) throw itemsError;

    return getOrderById(id) as Promise<Order>;
  } catch (error) {
    console.error('Supabase error in updateOrder:', error);
    throw error;
  }
};

export const updateOrderStatus = async (id: string, status: 'pending' | 'confirmed' | 'cancelled'): Promise<void> => {
    const { error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', id)
      .select();
      
    if (error) {
      console.error('Supabase error in updateOrderStatus:', error);
      throw error;
    }
};

export const deleteOrder = async (id: string): Promise<void> => {
  try {
    const { error: itemsError } = await supabase
      .from('order_items')
      .delete()
      .eq('order_id', id);
      
    if (itemsError) throw itemsError;

    const { error } = await supabase
      .from('orders')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  } catch (error) {
    console.error('Supabase error in deleteOrder:', error);
    throw error;
  }
};

export type { Customer };
export type { Product };
export type { Batch };
export type { Order };
